#define _FILE_OFFSET_BITS 64
#include "tst-chk3.c"
