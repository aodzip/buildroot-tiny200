#define _FORTIFY_SOURCE 1
#include "tst-chk1.c"
